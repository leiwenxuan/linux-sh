cd /etc/yum.repos.d  &&
mv CentOS-Base.repo CentOS-Base.repo.bk &&
wget http://mirrors.163.com/.help/CentOS7-Base-163.repo


